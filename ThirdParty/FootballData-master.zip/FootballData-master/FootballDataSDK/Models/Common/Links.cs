﻿namespace FootballDataSDK.Models.Common
{
    public class Links
    {
        public Link self { get; set; }
        public Link soccerseason { get; set; }
        public Link homeTeam { get; set; }
        public Link awayTeam { get; set; }
        
    }
}
