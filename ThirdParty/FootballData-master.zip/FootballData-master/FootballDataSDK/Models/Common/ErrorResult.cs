﻿namespace FootballDataSDK.Models.Common
{
    public class ErrorResult
    {
        public string error { get; set; }
    }
}
