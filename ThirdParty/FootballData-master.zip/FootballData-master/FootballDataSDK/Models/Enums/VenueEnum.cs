﻿namespace FootballDataSDK.Models.Enums
{
    public enum VenueEnum
    {
        home,
        away
    }
}
