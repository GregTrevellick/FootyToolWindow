﻿football data
FootballData SDK is an unofficial C# Library  allowing retrieving data 
from the popular api api.football-data.org.
It is intended for use by developer wishing to make theire own football result apps.



http://api.football-data.org/